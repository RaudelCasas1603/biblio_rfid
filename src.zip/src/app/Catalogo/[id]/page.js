"use client"; // Mover esta línea al principio del archivo

import { useRouter } from "next/router";

// Asegúrate de que este array de libros esté en un archivo accesible o
// hazlo dentro de este archivo si es necesario.
const Books = [
  {
    id: 1,
    titulo: "Cien años de soledad",
    autor: "Gabriel García Márquez",
    isbn: "9788497592208",
    fecha_publicacion: "1967-05-30",
    imagen: "/Portadas_Libros/Cien_años_de_soledad.jpg",
  },
  {
    id: 2,
    titulo: "1984",
    autor: "George Orwell",
    isbn: "9780451524935",
    fecha_publicacion: "1949-06-08",
    imagen: "/Portadas_Libros/1984.jpg",
  },
  // Agregar los otros libros...
];

export default function BookDetails() {
  const router = useRouter();
  const { id } = router.query; // Obtiene el `id` desde la URL

  // Buscar el libro en la lista de libros usando el id
  const book = Books.find((b) => b.id.toString() === id);

  if (!book) {
    return <p>Libro no encontrado</p>;
  }

  return (
    <div className="book-detail">
      <h1>{book.titulo}</h1>
      <p>Autor: {book.autor}</p>
      <p>ISBN: {book.isbn}</p>
      <p>Fecha de publicación: {book.fecha_publicacion}</p>
      <img src={book.imagen} alt={book.titulo} className="book-image" />
      {/* Puedes agregar más detalles como sinopsis, etc. */}
    </div>
  );
}
